<!DOCTYPE HTML>
<html lang="en">
	<head>
		<title>Ben Ventura CS008 - Test Page</title>
		<meta name="author" content="Ben Ventura">
		<meta name="description" content="A Page for experimenting with PHP HTML and CSS">
	</head>
	<body>
		<h1>This Page is a Test</h1>
	</body>
</html>